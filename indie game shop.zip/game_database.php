<!DOCTYPE html>
<html>

<head>
    <title>View Game Database</title>
</head>

<body>


    <div style="text-align: center;">
        <a href="employee_home.php" style="text-decoration: none; color: #777;">
            <h2> Employee Portal</h2>
        </a>
    </div><hr>

    <h2>Game Database</h2>
    <br><br>

    <?php
   
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "abd";
    $conn = new mysqli($servername, $username, $password, $dbname);

    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


   
    $sql = "SELECT * FROM game_database";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) 
    {

        echo "<table border='1'>";
        echo "<tr><th>No</th><th>Title</th><th>Description</th><th>Filepath</th><th>Sold</th></tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>{$row['No']}</td>";
            echo "<td>{$row['Title']}</td>";
            echo "<td>{$row['Description']}</td>";
            echo "<td>{$row['Filepath']}</td>";
            echo "<td>{$row['Sold']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No games found in the database.";
    }

    $conn->close();
    ?>

   
    <p><a href="upload_game.php">Upload a New Game</a></p>

    
</body>

</html>


