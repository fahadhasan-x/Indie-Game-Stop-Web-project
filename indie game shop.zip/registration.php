<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "abd";
$conn = new mysqli($servername, $username, $password, $dbname);

$message = ''; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];



    
    $sql = "INSERT INTO ab (Name, Email, Pass) VALUES ('$name', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        
        $lastInsertedId = $conn->insert_id;




        // Display a message with the last inserted ID
        $message = "Registration successful! Your Auto-Incremented ID is: $lastInsertedId";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error ;
    }
}
?>



<!DOCTYPE html>
<html>

<head>
    <title>Registration Page</title>
</head>

<body>
    <h2>Registration</h2>
    <form method="post">
        
        ID: <input type="number" name="id" placeholder="<?php echo $lastInsertedId ?? ''; ?>" readonly><br>
        Name: <input type="text" name="name" required><br>
        Email: <input type="email" name="email" required><br>
        Password: <input type="password" name="password" required><br>
        <input type="submit" value="Register">
    </form>
    
    <?php
   
    if (!empty($message)) {
        echo "<p>$message</p>";
    }
    ?>

    <p><a href="login.php">Back to Employee login </a></p>
</body>

</html>

