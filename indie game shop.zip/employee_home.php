<?php
session_start();

if (!isset($_SESSION['id'])) {
    header('location: login.php');
    exit();
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('location: login.php');
    exit();
}





$employeeDetails = getEmployeeDetails($_SESSION['id']);

function getEmployeeDetails($employeeId)
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "abd";
    $conn = new mysqli($servername, $username, $password, $dbname);




    
    $sql = "SELECT ID, Name FROM ab WHERE ID='$employeeId'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch employee details
        $employeeDetails = $result->fetch_assoc();
        return $employeeDetails;
    } else {
        
        return false;
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Employee Portal</title>
</head>

<body>





    <div style="text-align: center;">
        <a href="employee_home.php" style="text-decoration: none; color: #333;">
            <h2>Welcome Employee Portal</h2>
        </a>
    </div><hr><hr><br><br><br>





    

    <!-- employee information  -->
    <div style="position: absolute; top: 20px; right: 20px;">
        <?php
        
        if ($employeeDetails) {
            echo "ID: " . $employeeDetails['ID'] . " | ";
            echo "Name: " . $employeeDetails['Name'];
        } else {
            echo "Employee details not found";
        }
        ?>
    </div>







    
    <div style="position: absolute; top: 20px; left: 20px;">
        <form method="get">
            <button type="submit" name="logout">Logout</button>
        </form>
    </div>




    <!--   game_database table -->
    <div style="text-align: center; margin-top: 20px;">
        <button class="database-button" onclick="location.href='game_database.php'">Game Database Table</button>
    </div><hr>


    <div style="text-align: center; margin-top: 20px;">
        <button class="database-button" onclick="location.href='employee_Information.php'">Employee Information Table</button>
    </div><hr>



    
</body>

</html>
