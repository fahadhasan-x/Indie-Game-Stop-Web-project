
<!DOCTYPE html>
<html>

<head>
    <title>Login Page</title>

    <script>
        function showNotification() {
            alert("Invalid User. Please check your ID and Password.");
        }
    </script>

</head>



<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "abd";
$conn = new mysqli($servername, $username, $password, $dbname);





if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $pass = $_POST["pass"];

    $sql = "SELECT * FROM ab WHERE ID='$id' AND Pass='$pass'";
    $res = mysqli_query($conn, $sql);
    

if ($res->num_rows > 0) {
     while ($r = mysqli_fetch_assoc($res)) {
        $_SESSION['id'] = $r["ID"];
        header("location: employee_home.php");
    }
} else {
     echo '<script>showNotification();</script>';
    }
}
?>


<body>

    <div style="text-align: center;">
         
            <h2>Indie Game Store</h2>
       
    </div>

<h2>Login</h2>
    <form method="post">
        ID: <input type="number" name="id" required><br>
        Password: <input type="password" name="pass" required><br>
        <button type="submit">Login</button>
    </form>
    <p>Don't have an account? <a href="registration.php">Register here</a></p>
</body>

</html>

