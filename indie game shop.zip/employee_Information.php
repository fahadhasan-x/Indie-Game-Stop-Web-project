<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "abd";
$conn = new mysqli($servername, $username, $password, $dbname);


if (isset($_POST['del'])) {
    $a = $_POST['del'];
    $sql2 = "DELETE FROM ab WHERE ID='$a'";
    mysqli_query($conn, $sql2);
}



if (isset($_POST['add'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];




    if (empty($id)) {
        echo "ID is empty";
    } else {
        $sql3 = "INSERT INTO ab (ID, Name, Email, Pass) VALUES ('$id', '$name', '$email', '$pass')";
        mysqli_query($conn, $sql3);
    }
}




$sql = "SELECT * FROM ab";
$res = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Employee Information</title>
</head>

<body>

 <div style="text-align: center;">
        <a href="employee_home.php" style="text-decoration: none; color: #777;">
            <h2> Employee Portal</h2>
        </a>
    </div>




<h2> Employee Information</h2>

<form method="post">
 ID: <input type="number" name="id"><br>
 Name: <input type="text" name="name"><br>
 Email: <input type="text" name="email"><br>
 Pass: <input type="text" name="pass"><br>
 <button type="Submit" name="add">Add</button>
 </form>



<table border="1">
     <tr>
     <th>ID</th>
     <th>Name</th>
      <th>Email</th>
       <th>Operation</th>
        </tr>


 <?php while ($r = mysqli_fetch_assoc($res)) { ?>
  <tr>
  <td><?php echo $r["ID"]; ?></td>
   <td><?php echo $r["Name"]; ?></td>
  <td><?php echo $r["Email"]; ?></td>
  <td>
     <form method="post">
      <button type="Submit" name="del" value="<?php echo $r["ID"]; ?>">Delete</button>
     </form>
     <form method="get" action="edit.php">
     <input type="hidden" name="edit" value="<?php echo $r["ID"]; ?>">
      <button type="Submit">Edit</button>
         </form>
         </td>
      </tr>
 <?php } ?>
</table>

</body>

</html>
